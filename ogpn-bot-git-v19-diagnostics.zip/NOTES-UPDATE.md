# Notes de mise a jour OGPN Bot

## Attention au remplacement du depot GitHub

Cette archive est prevue comme une mise a jour a appliquer par-dessus le depot existant.
Avant tout remplacement complet du depot GitHub, verifier que les fichiers caches et
metadonnees du depot sont bien conserves, notamment :

- `.gitignore`
- `.github/workflows/scan.yml`

Si un ZIP est genere sans inclure les fichiers caches, un remplacement total du depot
peut supprimer le workflow horaire et les regles d'exclusion Git. Dans ce cas, appliquer
la mise a jour fichier par fichier ou regenerer une archive complete incluant les chemins
caches.

## Normalisation prudente : variantes singulier/pluriel

Le classifieur utilise volontairement des correspondances strictes sur les mots et les
expressions. Il ajoute maintenant des variantes de pluriel simples pour les termes
d'un seul mot, en fonction de la langue detectee lorsque c'est possible :

- francais : `livre/livres`, `jeu/jeux` ;
- anglais : `author/authors`, `company/companies` ;
- neerlandais/allemand : pluriels simples en `s` ou `en` ;
- espagnol/portugais : pluriels simples en `s` ou `es` ;
- turc : pluriels simples en `lar` ou `ler`.

Ce n'est pas une vraie lemmatisation. Les langues a declinaisons complexes, les formes
irregulieres, les accords masculin/feminin, les conjugaisons et les variantes metier
ambiguës doivent rester traitees progressivement dans les dictionnaires et les couples
de contexte.

Decision actuelle :

- eviter une regle universelle trop dangereuse ;
- couvrir les pluriels courants sans casser les limites de mots strictes ;
- ajouter les variantes evidentes lorsqu'un cas reel les revele ;
- garder `unidentified` comme resultat normal quand la page d'accueil ne donne pas assez
  de signaux.

## Dependances inconnues, performance et ethique

Le scanner conserve maintenant des `unknown_dependencies` separees des dependances
connues. Ce sont des domaines tiers candidats observes dans des sources fortes
deja telechargees (`script`, `iframe`, `embed`, `object`, `form`, stylesheet/preload),
pas des accusations de dependance non europeenne.

Decisions actuelles :

- aucune requete reseau supplementaire pour qualifier ces inconnus dans le scanner ;
- pas de DNS/MX/WHOIS dans la boucle principale, afin de garder un scan court par domaine ;
- exclusion des domaines first-party, des sous-domaines du site et des domaines de standards ;
- plafond volontaire sur le nombre d'inconnus conserves par site ;
- les inconnus servent a prioriser l'enrichissement des dictionnaires et les analyses agregees ;
- le score de souverainete peut etre plafonne par incertitude, mais un inconnu n'est pas traite
  comme une dependance rouge.

Correction importante : les signatures de dependances peuvent contenir un chemin
pour rester precises (`googletagmanager.com/gtag/js`, `accounts.google.com/gsi`,
etc.). Le filtrage des `unknown_dependencies` compare maintenant le host observe
au host extrait de ces signatures, afin d'eviter qu'une dependance deja reconnue
soit aussi stockee comme inconnue.

## Initialisation MySQL

`processing/process.php` peut creer la base configuree si elle n'existe pas encore,
lorsque `database.create_if_missing` vaut `true` dans `server-config.php`.

Le premier lancement applique ensuite `processing/schema.sql` si la table `domains`
est absente. Si l'utilisateur MySQL n'a pas le droit `CREATE DATABASE`, l'erreur reste
explicite : la base devra etre creee depuis le panneau d'hebergement.

## Durcissement API serveur

`scan-ingest.php` refuse maintenant les payloads trop volumineux avant de parser le JSON.
Objectif : eviter un usage excessif de memoire si un appel est mal forme ou si un jeton
est compromis.

`refresh-domains.php` filtre les domaines issus de Common Crawl avec `DomainSafety` avant
de les fusionner dans `domains.json`. Common Crawl reste une source d'observation, pas une
source de confiance brute.

Les fichiers de secrets serveur (`server-config.php`, `htpasswd-cron`) doivent etre crees
sur l'hebergement et ne sont pas fournis avec des valeurs reelles dans l'archive.
Le paquet serveur contient seulement `storage/secrets/htpasswd-cron.example`, volontairement
non exploitable s'il est copie tel quel.

## HTML allege pour analyse

Le scanner conserve le HTML brut pour les signaux techniques (`script`, `link`, CSP,
dependances connues et inconnues), mais utilise une version allegee pour les analyses
textuelles : langue, liens sociaux visibles, mentions et classification.

Cette version retire les gros blocs sans valeur semantique directe pour la categorie :
SVG inline, images, `picture`, scripts/styles inline, grands `srcset` et images base64.
Cela ne permet pas de lire au-dela des 150 Ko deja telecharges, mais evite que ces 150 Ko
soient domines par des assets verbeux au lieu de contenu exploitable.

Correction importante : les scripts ordinaires sont retires du HTML allege, mais les blocs
`<script type="application/ld+json">` sont conserves. Le JSON-LD reste le signal de
classification le plus fiable lorsqu'un site declare correctement son type schema.org.

## Gouvernance du consentement et tracking

Le scan distingue maintenant les signaux de tracking et de consentement sans les transformer
en verdict juridique automatique.

Familles ajoutees ou etendues :

- publicite comportementale et pixels sociaux actifs ;
- attribution/identifiants marketing ;
- analytics, monitoring navigateur, session replay et A/B testing ;
- plateformes de consentement (CMP) ;
- signaux TCF/IAB et candidats pay-or-consent.

Decision methodologique importante : un simple lien social TikTok, Pinterest, Facebook,
LinkedIn, etc. reste une presence sociale (`social_presence`) et ne compte pas comme
traceur. Seuls des scripts/endpoints actifs connus sont classes comme tracking.
Plus largement, les familles sensibles (analytics, tracking, CMP, paiement, captcha,
monitoring navigateur) sont recherchees dans les ressources actives (`script src`,
`iframe`, stylesheet/preload, formulaire, CSP), pas dans les liens editoriaux ordinaires.

Le scanner produit un `consent_friction_score_auto` de 0 a 5 et conserve
`consent_friction_score_manual` a `null` pour une revue humaine ulterieure. Les dark
patterns d'epuisement ou de contrainte doivent rester classes manuellement.

Cote MariaDB, les memes fournisseurs alimentent deux lectures separees :

- `dependencies` et `dependency_governance` pour la souverainete/dependance technique ;
- `consent_signals` pour la gouvernance tracking/cookies/consentement.

Le referentiel fournisseurs est maintenant un fichier versionne `data/providers.json`.
Le scan joint `provider_reference_version` et `provider_reference_sha256` a chaque resultat.
Cote Infomaniak, `provider_reference_snapshots` conserve une copie JSON du referentiel
utilise, utile comme preuve et pour reproduire une analyse plus tard.

Les colonnes scalaires facilitent les etudes : score automatique, score manuel, revue
necessaire, nombre de CMP, nombre de fournisseurs de tracking observes, nombre total de
dependances, dependances rouges et dependances ayant un role tracking/consentement.

## Dictionnaire francais et corpus de validation

Le dictionnaire francais `dictionaries/fr.json` est maintenant enrichi avec davantage
d'expressions completes et francophones, notamment pour les categories qui se confondent
facilement sur les pages d'accueil : formation, administration, sante, horeca, commerce,
immobilier, technologie, emploi, finance personnelle et maison/jardin.

Decision methodologique : l'amelioration prioritaire n'est pas d'ajouter du code, mais
de valider le dictionnaire sur un corpus de sites reels. Le fichier
`validation/fr-category-corpus.json` liste des domaines belges, francais, suisses ou
luxembourgeois attendus pour les categories et sous-categories existantes. Le script
`bin/validate-fr-corpus.php` scanne ce corpus et sort un CSV :

- categorie attendue ;
- categorie detectee ;
- sous-categorie attendue ;
- sous-categorie detectee ;
- score de confiance ;
- URL reellement analysee ;
- origine de la page analysee (`root`, `hreflang`, `standard_path`, `missing`) ;
- statut et source de classification ;
- langues detectees ;
- signaux positifs.

Les sites bloques par robots.txt ou trop generiques doivent etre remplaces dans le corpus.
Il ne faut pas contourner robots.txt pour un test de qualite. La categorie sensible adulte
reste prevue en test synthetique local uniquement, pas via URL publique.
