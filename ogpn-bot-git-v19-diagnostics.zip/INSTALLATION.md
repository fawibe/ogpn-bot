# Installation OGPN-BOT

Ce document couvre les deux parties du projet :

- le depot GitHub, qui lance le scan horaire avec GitHub Actions ;
- l'hebergement Infomaniak du domaine `bot.ogpn.eu`, qui expose l'API, conserve la file de domaines et traite les resultats en base MariaDB.

## 1. Installation GitHub

1. Creez ou ouvrez le depot GitHub destine au scanner.
2. Copiez le contenu de l'archive Git dans ce depot.
3. Verifiez que les fichiers caches sont bien presents :
   - `.github/workflows/scan.yml`
   - `.gitignore`
4. Commitez et poussez le depot.
5. Dans GitHub, ouvrez `Settings > Secrets and variables > Actions`.
6. Ajoutez les secrets suivants :
   - `OGPN_API_URL` : `https://bot.ogpn.eu/api`
   - `OGPN_API_TOKEN` : la meme valeur que `api.token` dans `storage/secrets/server-config.php` cote Infomaniak.

Le workflow `.github/workflows/scan.yml` s'execute toutes les heures et peut aussi etre lance manuellement depuis l'onglet `Actions`.

## 2. Installation Infomaniak pour bot.ogpn.eu

1. Deposez le contenu de l'archive Infomaniak dans le dossier du site `bot.ogpn.eu`.
2. Configurez le domaine pour pointer vers le dossier `public` si le panneau Infomaniak le permet.
3. Si le domaine pointe obligatoirement vers la racine du site, conservez les dossiers `api`, `processing`, `src` et `storage` hors exposition directe quand c'est possible. Le dossier `storage` contient un `.htaccess` de protection, mais il ne doit jamais etre considere comme public.
4. Copiez `server-config.example.php` vers :

```text
storage/secrets/server-config.php
```

5. Remplissez les valeurs :

```php
'api' => [
    'token' => 'UNE-VALEUR-LONGUE-ALEATOIRE',
],
'monitoring' => [
    'healthcheck_url' => '',
],
'database' => [
    'host' => '...',
    'database' => '...',
    'user' => '...',
    'password' => '...',
    'create_if_missing' => true,
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
],
'maxmind' => [
    'asn_db_path' => '/shared/maxmind/GeoLite2-ASN.mmdb',
],
```

Avec MariaDB 10.11, le schema et les migrations actuelles sont compatibles. Si l'utilisateur MySQL a le droit `CREATE DATABASE`, `processing/process.php` peut creer la base au premier lancement. Sinon, creez la base depuis le panneau Infomaniak puis relancez le traitement.

`processing/process.php` applique aussi automatiquement les fichiers SQL de `processing/migrations/` qui n'ont pas encore ete enregistres dans `applied_migrations`.

## 3. Protection du cron Common Crawl

Le point d'entree public du cron est :

```text
https://bot.ogpn.eu/api/refresh-domains.php
```

Il est protege par Basic Auth dans `public/api/.htaccess`. Le fichier reel ne doit pas etre livre dans le ZIP. Creez-le sur le serveur :

```text
storage/secrets/htpasswd-cron
```

Le fichier `storage/secrets/htpasswd-cron.example` est seulement un modele volontairement non exploitable.

Exemple de creation en SSH si `htpasswd` est disponible :

```bash
htpasswd -Bc storage/secrets/htpasswd-cron ogpn-cron
```

Dans le planificateur Infomaniak, utilisez l'URL avec l'identifiant cron si l'interface ne permet pas de renseigner le Basic Auth separement :

```text
https://ogpn-cron:MOT-DE-PASSE@bot.ogpn.eu/api/refresh-domains.php
```

Frequence conseillee : hebdomadaire ou toutes les deux semaines. Common Crawl n'est pas une API temps reel. Une extension active sans resultat Common Crawl n'est pas une erreur : cela signifie seulement qu'aucune URL exploitable n'a ete observee dans le snapshot interroge.

## 4. Traitement des resultats

Le traitement serveur se lance avec :

```bash
php /chemin/vers/bot.ogpn.eu/processing/process.php
```

Ce script lit les resultats stockes, cree la base si la configuration l'autorise, applique le schema si necessaire, puis insere ou met a jour les lignes.

Frequence conseillee : apres les scans GitHub, par exemple toutes les heures ou quelques fois par jour selon le volume.

## 5. Healthcheck optionnel

Pour surveiller le cron Common Crawl, renseignez :

```php
'monitoring' => [
    'healthcheck_url' => 'https://hc-ping.com/...',
],
```

Le ping est effectue uniquement a la fin d'un run reussi, avec un timeout court. Si le service de monitoring est indisponible, le run principal ne doit pas echouer.

## 6. Verifications rapides

Apres installation :

1. Ouvrez `https://bot.ogpn.eu/api/scan-queue.php` sans token : la reponse doit etre refusee.
2. Ouvrez `https://bot.ogpn.eu/api/refresh-domains.php` sans Basic Auth : la reponse doit etre refusee.
3. Lancez manuellement le workflow GitHub `Scan horaire`.
4. Lancez `processing/process.php` en SSH ou via cron.
5. Verifiez que les tables MariaDB sont creees et que les resultats apparaissent.

## 7. Consentement et tracking

Le scan detecte maintenant des signaux de gouvernance du consentement :

- plateformes publicitaires et pixels sociaux actifs ;
- analytics commerciaux ou sobres ;
- monitoring navigateur, session replay et A/B testing ;
- plateformes de consentement (CMP) ;
- indices HTML de bandeau, acceptation, refus, parametrage, TCF/IAB et pay-or-consent.

Un lien social simple, par exemple vers une page TikTok ou Pinterest, est stocke dans `social_presence` et ne compte pas comme traceur. Seuls les scripts/endpoints actifs connus, par exemple `analytics.tiktok.com`, `s.pinimg.com/ct/` ou `ct.pinterest.com`, declenchent un signal de tracking. Les familles sensibles sont recherchees dans les ressources actives et la CSP, pas dans les liens editoriaux ordinaires.

Les commentaires HTML sont retires avant l'analyse technique : un ancien script commente ou une note de developpeur ne doit pas devenir une preuve de tracking actif.

Les memes fournisseurs sont aussi stockes dans `dependencies`, car ils restent des dependances techniques et de souverainete. Cette lecture utilise `dependency_governance`, `dependency_provider_count`, `dependency_red_count`, `dependency_tracking_role_count` et le score global `eu_sovereignty_score`.

Le referentiel des fournisseurs est versionne dans `data/providers.json`. Chaque resultat embarque `provider_reference_version` et `provider_reference_sha256`, afin de prouver avec quelle version du referentiel le scan a ete produit. Cote Infomaniak, `process.php` conserve aussi un snapshot dans `provider_reference_snapshots`.

Le champ JSON `consent_signals` contient la lecture consentement/tracking. Les colonnes scalaires `consent_friction_score_auto`, `consent_friction_score_manual`, `consent_review_needed`, `consent_cmp_count` et `consent_tracking_provider_count` facilitent les requetes d'etude.

Important : `consent_friction_score_auto` est un indice heuristique 0-5, pas un verdict juridique. Le vrai classement des dark patterns d'epuisement ou de contrainte doit passer par `consent_friction_score_manual` apres revue humaine.

## 8. Fichiers a ne jamais publier

Ne placez jamais ces fichiers dans GitHub ni dans une archive partagee :

- `storage/secrets/server-config.php`
- `storage/secrets/htpasswd-cron`
- dumps SQL contenant des resultats reels
- logs contenant des tokens, IP ou donnees techniques non anonymisees
